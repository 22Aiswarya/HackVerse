from flask import Flask, render_template, request
import numpy as np
import pickle
import pandas as pd
from sklearn import preprocessing 

app = Flask(__name__)
model = pickle.load(open('life_expetency.pkl','rb'))

@app.route('/')

def home():
    return render_template('life.html.html')

@app.route('/predict', methods = ['POST','GET'])

def predict():
         if request.method == 'POST':
            country = request.form.get("country")
            year = request.form.get("year")
            status  = request.form.get('status')
            adult_mortality = request.form.get("adult_mortality")
            alcohol= request.form.get ("alcohol")
            percentage_expenditure = request.form.get ("percentage_expenditure")
            measles = request.form.get("measles")
            bmi = request.form.get ("bmi")
            polio = request.form.get("polio")
            total_expenditure = request.form.get ("total_expenditure")
            diphtheria = request.form.get("diphtheria")
            HIV_AIDS = request.form.get ("HIV_AIDS")
            GDP = request.form.get("GDP")
            population = request.form.get ("population")
            thinness_10_19_years = request.form.get ("thinness_10_19_years")
            income_composition_of_resources = request.form.get ("income_composition_of_resources")
            schooling = request.form.get ("schooling")
            dict1={
                'country' : str(country),
                'year' : str(year),
                'status' : str(status),
                'alcohol': float(alcohol),
                'adult_mortality':float(adult_mortality),
                'percentage_expenditure': float(percentage_expenditure),
                'measles': float(measles),
                'bmi': float(bmi),
                'polio': float(polio),
                'total_expenditure': float(total_expenditure),
                'diphtheria': float(diphtheria),
                'HIV/AIDS': float(HIV_AIDS),
                'GDP':float(GDP),
                'population': float(population),
                'thinness_1-19_years': float(thinness_10_19_years),
                'income_composition_of_resources': float(income_composition_of_resources),
                'schooling':float(schooling),

            }
            df = pd.DataFrame([dict1])
            
            label_encoder = preprocessing.LabelEncoder()
            df['country']= label_encoder.fit_transform(df['country']) 
            df['status']= label_encoder.fit_transform(df['status'])
            print(df)
            prediction = model.predict(df)
            
            return render_template('life.html.html', pred='Life Expectancy of a population in a country is: {} '.format(prediction))

if __name__ == '__main__':
    app.run(port=3000,debug=True)


